#include <stdio.h>
#include <stdlib.h>

void print_matrix( unsigned char * plain_text );

void print_matrix_in_int( unsigned char * plain_text );

void print_whole_key( unsigned char * whole_key );